DROP PROCEDURE IF EXISTS MultiSearch
GO;

CREATE PROCEDURE MultiSearch @title NVARCHAR(256), @personName NVARCHAR(256), @genreName NVARCHAR(32)
AS

IF @title = NULL AND @personName = NULL
	-- Search by genre --
	SELECT DISTINCT Title FROM Movie.Movies M
	JOIN Movie.MovieGenre MG ON MG.MovieID = M.MovieID
	JOIN Movie.Genre G ON G.GenreName = MG.GenreName
	WHERE MG.GenreName = @genreName

ELSE IF @title = NULL AND @genreName = NULL
	-- Search by person --
	SELECT DISTINCT Title FROM Movie.Movies M
	JOIN Movie.Actor A on A.MovieID = M.MovieID
	JOIN Movie.Director D on D.MovieID = M.MovieID
	JOIN Movie.Person P on P.Name = @personName
	WHERE P.PersonID = D.PersonID OR P.PersonID = A.PersonID

ELSE IF @genreName = NULL AND @personName = NULL
	-- Search by title --
	SELECT M.Title FROM Movie.Movies M
	WHERE M.Title LIKE @title

ELSE IF @title = NULL
	-- Search by person/genre --
	SELECT DISTINCT Title FROM Movie.Movies M
	JOIN Movie.MovieGenre MG ON MG.MovieID = M.MovieID
	JOIN Movie.Actor A on A.MovieID = M.MovieID
	JOIN Movie.Director D on D.MovieID = M.MovieID
	JOIN Movie.Genre G ON G.GenreName = MG.GenreName
	JOIN Movie.Person P on P.Name = @personName
	WHERE MG.GenreName = @genreName AND (P.PersonID = D.PersonID OR P.PersonID = A.PersonID)

ELSE IF @genreName = NULL
	-- Search by person/title --
	SELECT DISTINCT Title FROM Movie.Movies M
	JOIN Movie.Actor A on A.MovieID = M.MovieID
	JOIN Movie.Director D on D.MovieID = M.MovieID
	JOIN Movie.Person P on P.Name = @personName
	WHERE M.Title = @title AND (P.PersonID = D.PersonID OR P.PersonID = A.PersonID)

ELSE IF @personName = NULL
	-- Search by title/genre --
	SELECT DISTINCT Title FROM Movie.Movies M
	JOIN Movie.MovieGenre MG ON MG.MovieID = M.MovieID
	JOIN Movie.Genre G ON G.GenreName = MG.GenreName
	WHERE MG.GenreName = @genreName AND M.Title = @title